# Distributed Database Lab — PostgreSQL 18

    docker compose up -d          # start hq (5440), lhr (5441), khi (5442)
    docker exec -it hq psql -U postgres -d unidb

Run the scripts in this order (inside psql: \i /lab/<file>):

| Step | Node       | Script                              |
|------|------------|-------------------------------------|
| B    | lhr        | 01_site_lhr.sql                     |
| B    | khi        | 01_site_khi.sql                     |
| C    | hq         | 02_hq_global_schema.sql             |
| E    | hq         | 03_hq_courses_publisher.sql         |
| E    | lhr        | 03_lhr_courses_subscriber.sql       |
| E    | khi        | 03_khi_courses_subscriber.sql       |

Parts D, F and G are typed by hand from the lab manual.
Clean up: docker compose down -v
