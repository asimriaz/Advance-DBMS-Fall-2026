-- Run on: khi      docker exec -it khi psql -U postgres -d unidb -f /lab/01_site_khi.sql
CREATE TABLE students (
    student_id  int          PRIMARY KEY,
    name        text         NOT NULL,
    campus      char(3)      NOT NULL CHECK (campus = 'KHI'),
    program     text         NOT NULL,
    cgpa        numeric(3,2) CHECK (cgpa BETWEEN 0 AND 4)
);

CREATE TABLE enrollments (
    student_id  int  NOT NULL REFERENCES students(student_id),
    course_code text NOT NULL,
    semester    text NOT NULL,
    grade       text,
    PRIMARY KEY (student_id, course_code, semester)
);

INSERT INTO students VALUES
 (2001,'Sana Iqbal'   ,'KHI','BSCS',3.45),
 (2002,'Ahmed Siddiqui','KHI','BSAI',3.78),
 (2003,'Maria Shah'   ,'KHI','BSCS',2.95),
 (2004,'Omar Farooq'  ,'KHI','BSSE',3.05),
 (2005,'Hira Baig'    ,'KHI','BSCS',3.55);

INSERT INTO enrollments VALUES
 (2001,'CS-501','Fall-2026','B+'), (2002,'CS-504','Fall-2026','A'),
 (2002,'CS-502','Fall-2026','A-'), (2003,'CS-501','Fall-2026','C+'),
 (2004,'CS-503','Fall-2026','B'),  (2005,'CS-502','Fall-2026','B+');
