-- Run on: lhr      docker exec -it lhr psql -U postgres -d unidb -f /lab/01_site_lhr.sql
-- Horizontal fragment: students WHERE campus = 'LHR'
CREATE TABLE students (
    student_id  int          PRIMARY KEY,
    name        text         NOT NULL,
    campus      char(3)      NOT NULL CHECK (campus = 'LHR'),
    program     text         NOT NULL,
    cgpa        numeric(3,2) CHECK (cgpa BETWEEN 0 AND 4)
);

-- Derived horizontal fragment: enrollments of LHR students only
CREATE TABLE enrollments (
    student_id  int  NOT NULL REFERENCES students(student_id),
    course_code text NOT NULL,
    semester    text NOT NULL,
    grade       text,
    PRIMARY KEY (student_id, course_code, semester)
);

INSERT INTO students VALUES
 (1001,'Ayesha Khan','LHR','BSCS',3.62),
 (1002,'Bilal Ahmed','LHR','BSCS',3.10),
 (1003,'Hamza Tariq','LHR','BSSE',2.85),
 (1004,'Fatima Noor','LHR','BSCS',3.91),
 (1005,'Usman Ali'  ,'LHR','BSAI',3.25),
 (1006,'Zainab Raza','LHR','BSSE',2.40);

INSERT INTO enrollments VALUES
 (1001,'CS-501','Fall-2026','A'),  (1001,'CS-502','Fall-2026','B+'),
 (1002,'CS-501','Fall-2026','B'),  (1003,'CS-503','Fall-2026','C+'),
 (1003,'CS-501','Fall-2026','B-'), (1004,'CS-502','Fall-2026','A'),
 (1005,'CS-504','Fall-2026','A-'), (1006,'CS-503','Fall-2026','C');
