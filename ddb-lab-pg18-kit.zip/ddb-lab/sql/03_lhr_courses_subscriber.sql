-- Run on: lhr  — full replica of the COURSES reference table from hq
CREATE TABLE courses (
    course_code  text PRIMARY KEY,
    title        text NOT NULL,
    credit_hours int  NOT NULL
);

CREATE SUBSCRIPTION sub_courses_lhr
    CONNECTION 'host=hq port=5432 dbname=unidb user=postgres password=postgres'
    PUBLICATION pub_courses;
