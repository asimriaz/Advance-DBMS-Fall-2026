-- Run on: hq       docker exec -it hq psql -U postgres -d unidb -f /lab/02_hq_global_schema.sql
CREATE EXTENSION IF NOT EXISTS postgres_fdw;

-- 1. One foreign server per site (async_capable lets HQ scan sites in parallel)
CREATE SERVER lhr_srv FOREIGN DATA WRAPPER postgres_fdw
    OPTIONS (host 'lhr', port '5432', dbname 'unidb', async_capable 'true');
CREATE SERVER khi_srv FOREIGN DATA WRAPPER postgres_fdw
    OPTIONS (host 'khi', port '5432', dbname 'unidb', async_capable 'true');

-- 2. How the local user logs in at each site
CREATE USER MAPPING FOR postgres SERVER lhr_srv OPTIONS (user 'postgres', password 'postgres');
CREATE USER MAPPING FOR postgres SERVER khi_srv OPTIONS (user 'postgres', password 'postgres');

-- 3. Raw access to each site (one schema per site)
CREATE SCHEMA lhr;
CREATE SCHEMA khi;
IMPORT FOREIGN SCHEMA public LIMIT TO (students, enrollments) FROM SERVER lhr_srv INTO lhr;
IMPORT FOREIGN SCHEMA public LIMIT TO (students, enrollments) FROM SERVER khi_srv INTO khi;

-- 4. Global relation STUDENTS = union of horizontal fragments
--    (partitioned table whose partitions are FOREIGN tables)
CREATE TABLE students (
    student_id  int          NOT NULL,
    name        text         NOT NULL,
    campus      char(3)      NOT NULL,
    program     text         NOT NULL,
    cgpa        numeric(3,2)
) PARTITION BY LIST (campus);

CREATE FOREIGN TABLE students_lhr PARTITION OF students FOR VALUES IN ('LHR')
    SERVER lhr_srv OPTIONS (table_name 'students');
CREATE FOREIGN TABLE students_khi PARTITION OF students FOR VALUES IN ('KHI')
    SERVER khi_srv OPTIONS (table_name 'students');

-- 5. Global relation ENROLLMENTS = union of derived fragments (view approach)
CREATE VIEW enrollments AS
    SELECT 'LHR'::char(3) AS campus, * FROM lhr.enrollments
    UNION ALL
    SELECT 'KHI'::char(3) AS campus, * FROM khi.enrollments;

-- 6. Vertical fragment kept at HQ (finance office): fee columns of STUDENT
CREATE TABLE student_fees (
    student_id  int PRIMARY KEY,
    fee_due     numeric(10,2) NOT NULL,
    fee_paid    numeric(10,2) NOT NULL DEFAULT 0
);
INSERT INTO student_fees VALUES
 (1001,180000,180000),(1002,180000,90000),(1003,165000,165000),
 (1004,180000,180000),(1005,195000,100000),(1006,165000,0),
 (2001,180000,180000),(2002,195000,195000),(2003,180000,60000),
 (2004,165000,165000),(2005,180000,120000);
