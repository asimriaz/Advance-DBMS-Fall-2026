-- Run on: hq   — the master copy of the replicated reference table
CREATE TABLE courses (
    course_code  text PRIMARY KEY,
    title        text NOT NULL,
    credit_hours int  NOT NULL
);
INSERT INTO courses VALUES
 ('CS-501','Advanced Database Management Systems',3),
 ('CS-502','Distributed Systems',3),
 ('CS-503','Software Construction',3),
 ('CS-504','Machine Learning',3);

CREATE PUBLICATION pub_courses FOR TABLE courses;
